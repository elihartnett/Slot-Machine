import SwiftUI

struct ContentView: View {
    @State var number = [0, 0, 0]
    let height = 200.0
    @State var spin = false
    var body: some View {
        VStack {
            
            Text("Slot Machine")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            HStack(alignment: .top) {
                ForEach(0..<3, id: \.self) { index in
                    NumberWheel(number: number[index])
                        .frame(width: 100, height: height)
                }
                
                PullHandle(maxHeight: height, spin: $spin)
                    .onChange(of: spin) { _ in
                        spinWheel()
                    }
            }
            
            Button { 
                number = [0, 0, 0]
            } label: { 
                Text("Reset")
            }
        }
    }
    
    func spinWheel() {
        number[0] = Int.random(in: 0...9)
        number[1] = Int.random(in: 0...9)
        number[2] = Int.random(in: 0...9)
    }
}

struct NumberWheel: View {
    
    let number: Int
    
    var body: some View {
        
        Text("   ")
            .font(.largeTitle)
            .fontWeight(.regular)
            .overlay(
                GeometryReader { proxy in
                    VStack(spacing: 0) {
                        ForEach(0...9, id: \.self) { index in
                            Text(index.description)
                                .font(.largeTitle)
                                .fontWeight(.regular)
                                .frame(width: proxy.size.width, height: proxy.size.height)
                                .offset(y: CGFloat(-number) * proxy.size.height)
                                .animation(.spring(response: 0.5, dampingFraction: 1 + (0.15 * Double(number)), blendDuration: 1), value: number)
                        }
                    }
                }
                    .clipped()
            )
    }
}

struct PullHandle: View {
    @State var offset = 0.0
    let maxHeight: Double
    @State var markForSpin = false
    @Binding var spin: Bool
    @State var thisVal = 0.0
    
    var body: some View {
        ZStack(alignment: .top) {
            
            Rectangle()
                .frame(width: 5, height: maxHeight)
            
            Circle()
                .frame(width: 20, height: 20)
                .offset(y: offset)
                .foregroundColor(markForSpin ? .red : .black)
                .animation(.default, value: offset)
                .gesture(
                    DragGesture()
                        .onChanged({ value in
                            thisVal = value.translation.height
                            if 0...maxHeight ~= value.translation.height {
                                offset = value.translation.height
                                markForSpin = false
                            }
                            else if value.translation.height > maxHeight {
                                markForSpin = true
                            }
                        })
                        .onEnded({ _ in
                            if markForSpin {
                                spin.toggle()
                            }
                            markForSpin = false
                            offset = 0
                        })
                )
        }
    }
}
